export interface Delivery { id: string; date: string; meetha: number; flavour: number; }
export interface Invoice { id: string; billTo: string; invoiceNo: string; invoiceDate: string; address: string; rows: Delivery[]; }
export const MEETHA_PRICE = 2;
export const FLAVOUR_PRICE = 3;
export function today(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}
export function validDate(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(s+'T12:00:00Z');
  return !isNaN(d.getTime()) && d.toISOString().slice(0,10) === s && s >= '1900-01-01' && s <= '9999-12-31';
}
export function addDays(date: string, days: number): string {
  if (!validDate(date)) throw new Error('Choose a valid starting date.');
  const d = new Date(date+'T12:00:00Z');
  d.setUTCDate(d.getUTCDate()+days);
  const result = d.toISOString().slice(0,10);
  if (!validDate(result)) throw new Error('The date range is too large.');
  return result;
}
export function newRow(date = ''): Delivery { return {id: crypto.randomUUID(),date,meetha:0,flavour:0}; }
export function newInvoice(sequence = 1): Invoice {
  return {id:crypto.randomUUID(),billTo:'',invoiceNo:`${today().replaceAll('-','')}-${String(sequence).padStart(2,'0')}`,invoiceDate:today(),address:'5620 Vendelay Lane, Cumming, GA 30040',rows:[newRow(today()),newRow(),newRow(),newRow(),newRow()]};
}
export function totals(rows: Delivery[]) {
  const meetha = rows.reduce((s,r)=>s+(Number.isInteger(r.meetha)&&r.meetha>=0?r.meetha:0),0);
  const flavour = rows.reduce((s,r)=>s+(Number.isInteger(r.flavour)&&r.flavour>=0?r.flavour:0),0);
  return {meetha,flavour,meethaAmount:meetha*MEETHA_PRICE,flavourAmount:flavour*FLAVOUR_PRICE,grandTotal:meetha*MEETHA_PRICE+flavour*FLAVOUR_PRICE};
}
export function rowAmount(r: Delivery) { return totals([r]).grandTotal; }
export function quantityValid(n: number): boolean { return Number.isInteger(n)&&n>=0&&n<=1000000; }
export function ledgerError(doc: Invoice): string {
  for(let i=0;i<doc.rows.length;i++) {
    const r=doc.rows[i];
    if(!quantityValid(r.meetha)||!quantityValid(r.flavour)) return `Row ${i+1}: enter a whole quantity from 0 to 1,000,000.`;
    if((r.meetha>0||r.flavour>0)&&!validDate(r.date)) return `Row ${i+1}: choose a delivery date.`;
  }
  return '';
}
export function invoiceError(doc: Invoice): string {
  return ledgerError(doc)||(!doc.billTo.trim()?'Enter a customer in Bill to.':'')||(!doc.invoiceNo.trim()?'Enter an invoice number.':'')||(!validDate(doc.invoiceDate)?'Choose an invoice date.':'')||(totals(doc.rows).grandTotal===0?'Enter at least one paan quantity.':'');
}
export function filledRows(rows: Delivery[], from: number, to: number, step=1): Delivery[] {
  if(!Number.isInteger(from)||!Number.isInteger(to)||from<0||to<0||from>=rows.length||to>=rows.length||!Number.isInteger(step)||step<1||step>365) throw new Error('Choose a valid date range.');
  const source=rows[from].date;
  return rows.map((r,i)=>i>=Math.min(from,to)&&i<=Math.max(from,to)?{...r,date:addDays(source,(i-from)*step)}:r);
}
export function cleanInvoice(input: unknown): Invoice {
  const d=input as Invoice;
  if(!d||typeof d!=='object'||typeof d.id!=='string'||!/^[\da-f-]{36}$/i.test(d.id)||!Array.isArray(d.rows)||d.rows.length<1||d.rows.length>500) throw new Error('Invalid invoice.');
  for(const key of ['billTo','invoiceNo','invoiceDate','address'] as const) if(typeof d[key]!=='string'||d[key].length>(key==='address'?500:200)) throw new Error('Invalid invoice details.');
  if(!validDate(d.invoiceDate)) throw new Error('Choose a valid invoice date.');
  const seen=new Set<string>();
  const rows=d.rows.map(r=>{
    if(!r||typeof r.id!=='string'||!/^[\da-f-]{36}$/i.test(r.id)||seen.has(r.id)||typeof r.date!=='string'||(r.date!==''&&!validDate(r.date))||!quantityValid(r.meetha)||!quantityValid(r.flavour)) throw new Error('Invalid delivery row.');
    seen.add(r.id);return {id:r.id,date:r.date,meetha:r.meetha,flavour:r.flavour};
  });
  return {id:d.id,billTo:d.billTo.trim(),invoiceNo:d.invoiceNo.trim(),invoiceDate:d.invoiceDate,address:d.address.trim(),rows};
}
